import React, { useState, useEffect } from 'react';
import './App.css';
import NavBar from './NavBar';
import FileOperations from './components/FileOperations';
import LogData from './components/LogData';
import CodeFormatter from './components/CodeFormatter';
import { fetchFileList } from './services/fileService';
import { fetchTodayLogs } from './services/logService';
import useApi from './hooks/useApi';

function App() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [todayLogs, setTodayLogs] = useState("");

  const { data: fileList, request: getFileList } = useApi(fetchFileList);
  const { request: getTodayLogs } = useApi(fetchTodayLogs);

  useEffect(() => {
    getFileList();
    getTodayLogs().then(setTodayLogs);
  }, [getFileList, getTodayLogs]);

  const updateFileList = () => {
    getFileList();
  };

  return (
    <div className="App">
      <NavBar />
      <header className="App-header">
        <img src="/33.png" className="image-size" alt="Header Image" />
      </header>
      <main className="App-main">
        <FileOperations
          selectedFile={selectedFile}
          onFileSelect={setSelectedFile}
          onFileListUpdate={updateFileList}
        />
        <CodeFormatter />
        <LogData logs={todayLogs} setLogs={setTodayLogs} />
      </main>
    </div>
  );
}

export default App;
