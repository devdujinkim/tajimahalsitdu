import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

const SERVER_URL = 'http://localhost:8080'; // 서버 URL을 실제 서버의 URL로 변경해야 합니다.

const RealTimeLogs = () => {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const socket = io(SERVER_URL);

    socket.on('log update', (logEntry) => {
      // 새로운 로그 엔트리를 기존 로그에 추가합니다.
      setLogs((prevLogs) => [...prevLogs, logEntry]);
    });

    // 컴포넌트 언마운트 시 소켓 연결을 종료합니다.
    return () => {
      socket.disconnect();
    };
  }, []);

  // 로그 엔트리를 한 줄로 표시합니다.
  const renderLogEntry = (logEntry) => {
    return `${logEntry.ip} | ${logEntry.country_name} | ${logEntry.state_prov} | ${logEntry.city} | ${logEntry.timezone} | ${logEntry.currentTime} | ${logEntry.isp}`;
  };

  return (
    <div>
      <h2>Real-Time Logs</h2>
      <div>
        {logs.map((log, index) => (
          <div key={index}>{renderLogEntry(log)}</div>
        ))}
      </div>
    </div>
  );
};

export default RealTimeLogs;
