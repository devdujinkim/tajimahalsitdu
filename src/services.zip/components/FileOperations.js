import React from 'react';
import Button from 'react-bootstrap/Button';
import { uploadFile, downloadFile, deleteFile, verifyPassword } from '../services/fileService';

const FileOperations = ({ selectedFile, onFileListUpdate }) => {
  const apiURL = "https://api.tajimahalsitdu.it";

  const handleFileChange = async (event) => {
    const files = event.target.files;

    if (files.length > 0) {
      const formData = new FormData();
      formData.append('file', files[0]);

      try {
        const uploadResponse = await uploadFile(formData, apiURL);
        console.log('File uploaded successfully', uploadResponse);
        if (uploadResponse.success) {
          // 업로드 성공 시에만 파일 목록을 업데이트합니다.
          onFileListUpdate();
        } else {
          console.error('Upload failed:', uploadResponse.error);
        }
      } catch (error) {
        console.error('Upload failed:', error);
      }
    }
  };

  const handleDownload = async () => {
    if (!selectedFile) {
      alert('Please select a file to download.');
      return;
    }
    
    const passwordInput = prompt("Please enter the password for download:");
    if (passwordInput) {
      const isPasswordValid = await verifyPassword(passwordInput, 'download');
      if (isPasswordValid) {
        downloadFile(selectedFile, apiURL);
      } else {
        alert('Invalid password');
      }
    }
  };
  const handleDelete = async () => {
    if (!selectedFile) {
      alert('Please select a file to delete.');
      return;
    }
  
    const passwordInput = prompt("Please enter the password for deletion:");
    if (passwordInput) {
      const deleteResponse = await deleteFile(selectedFile, passwordInput);
      if (deleteResponse.success) {
        onFileListUpdate();
        alert('File deleted successfully');
      } else {
        alert(deleteResponse.error || 'File deletion failed');
      }
    }
  };
  
  

  return (
    <div className="File-operations">
      <input
        id="file-upload"
        type="file"
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />
      <label htmlFor="file-upload" className="button-style">
        Upload File
      </label>
      <div className="button-container">
        <Button onClick={handleDownload} className="button-style">Download Selected File</Button>
        <Button onClick={handleDelete} className="button-style">Delete Selected File</Button>
      </div>
    </div>
  );
};

export default FileOperations;
