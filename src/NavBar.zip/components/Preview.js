// Preview.js

import React from 'react';

const Preview = ({ selectedFile }) => {
  // 파일의 확장자를 확인하여 유형을 결정합니다.
  const fileExtension = selectedFile.split('.').pop().toLowerCase();

  // 이미지 파일인지 확인합니다.
  const isImage = fileExtension === 'jpg' || fileExtension === 'jpeg' || fileExtension === 'png' || fileExtension === 'gif';

  // 동영상 파일인지 확인합니다.
  const isVideo = fileExtension === 'mp4' || fileExtension === 'avi' || fileExtension === 'mov';

  // 선택된 파일에 따라 적절한 미리보기를 표시합니다.
  return (
    <div className="Preview">
      {isImage && (
        <img src={selectedFile} alt="Preview" className="Preview-image" />
      )}
      {isVideo && (
        <video controls className="Preview-video">
          <source src={selectedFile} type={`video/${fileExtension}`} />
          Your browser does not support the video tag.
        </video>
      )}
      {!isImage && !isVideo && (
        <div className="Preview-placeholder">
          Preview not available for this file type.
        </div>
      )}
    </div>
  );
};

export default Preview;
