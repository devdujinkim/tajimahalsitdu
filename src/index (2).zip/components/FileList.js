import React from 'react';
import ReactPlayer from 'react-player';
import './FileList.css';

const FileList = ({ fileList, selectedFile, handleFileSelect }) => {
  const renderPreview = (file) => {
    if (file === selectedFile) {
      if (file.type && file.type.startsWith('image/')) {
        return <img src={URL.createObjectURL(file)} alt={file.name} style={{ maxWidth: '200px', maxHeight: '200px' }} />;
      }

      if (file.type && file.type.startsWith('video/')) {
        return <ReactPlayer url={URL.createObjectURL(file)} width="200px" height="200px" controls />;
      }
    }

    return null;
  };

  return (
    <div className="file-list">
      {fileList.map((file, index) => (
        <div
          key={index}
          className={`file-item ${file === selectedFile ? 'selected' : ''}`}
          onClick={() => handleFileSelect(file)}
        >
          <span className="file-name">{file.name}</span> {/* 파일 이름을 span 태그로 감쌌습니다 */}
          <div className="file-preview">
            {renderPreview(file)}
          </div>
        </div>
      ))}
    </div>
  );
};

export default FileList;
