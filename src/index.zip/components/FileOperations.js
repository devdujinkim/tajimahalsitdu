import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import { uploadFile, downloadFile, deleteFile, verifyPassword } from '../services/fileService';

const FileOperations = ({ selectedFile, onFileListUpdate }) => {
  const [password, setPassword] = useState("");

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('file', file);
      try {
        await uploadFile(formData); // 업로드 시 비밀번호 필요 없음
        onFileListUpdate();
      } catch (error) {
        alert(error.message);
      }
    }
  };

  const handleDownload = async () => {
    if (!selectedFile) {
      alert('Please select a file to download.');
      return;
    }
    
    const passwordInput = prompt("Please enter the password for download:"); // 다운로드 시 비밀번호 입력 받기
    if (passwordInput !== null) { // 취소 버튼을 누른 경우 처리
      try {
        const isPasswordValid = await verifyPassword(passwordInput, true); // 다운로드 시 PASSWORD 사용
        if (!isPasswordValid) {
          alert('Invalid password');
          return;
        }

        downloadFile(selectedFile);
      } catch (error) {
        alert(error.message);
      }
    }
  };

  const handleDelete = async () => {
    if (!selectedFile) {
      alert('Please select a file to delete.');
      return;
    }
    
    const passwordInput = prompt("Please enter the password for deletion:"); // 삭제 시 비밀번호 입력 받기
    if (passwordInput !== null) { // 취소 버튼을 누른 경우 처리
      try {
        const isPasswordValid = await verifyPassword(passwordInput, false); // 삭제 시 CLEAR_LOGS_PASSWORD 사용
        if (!isPasswordValid) {
          alert('Invalid password');
          return;
        }
  
        // 삭제 작업을 비밀번호가 유효한 경우에만 수행
        await deleteFile(selectedFile, passwordInput); // 파일 삭제 요청 시 입력받은 비밀번호 전달
        onFileListUpdate();
        alert('File deleted successfully');
      } catch (error) {
        alert(error.message);
      }
    }
  };
  

  return (
    <div className="File-operations">
      <input
        id="file-upload"
        type="file"
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />
      <label htmlFor="file-upload" className="button-style">
        Upload File
      </label>
      <div className="button-container">
        <Button onClick={handleDownload} className="button-style">Download Selected File</Button>
        <Button onClick={handleDelete} className="button-style">Delete Selected File</Button>
      </div>
    </div>
  );
};

export default FileOperations;
