import React from 'react';
import Button from 'react-bootstrap/Button';
import { clearLogs } from '../services/logService';
import { convertLogsToHTML } from '../utils/helpers';

const LogData = ({ logs, setLogs }) => {
    const handleClearLogs = async () => {
      try {
        await clearLogs();
        setLogs('');
      } catch (error) {
        alert(error.message);
      }
    };
  
    // logs가 undefined인 경우를 처리
    const logsHTML = logs ? convertLogsToHTML(logs) : '';
  
    return (
      <div className="log-data">
        <h2>Today's Logs</h2>
        <div dangerouslySetInnerHTML={{ __html: logsHTML }} />
        <Button onClick={handleClearLogs} className="button-style">Clear Logs</Button>
      </div>
    );
  };
  
  export default LogData;
  